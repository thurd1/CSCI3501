
public class Processor {

    private Memory memory;
    private int[] registers = new int[8];
    private int PC;
    private int IR;

    public Processor(Memory memory) {
        this.memory = memory;
    }

    public void setPC(int PC) {
        this.PC = PC;
    }

    public void dump() {
        System.out.println("Registers:");
        for (int i = 0; i < registers.length; i++) {
            System.out.printf("reg[%d] = %08X%n", i, registers[i]); //Format as hexadecimal
        }
        System.out.printf("PC = %08X%n", PC); //Format as hexadecimal
        System.out.printf("IR = %08X%n", IR); //Format as hexadecimal
    }

    public boolean step() {
    IR = memory.read(PC);
    int opcode = (IR & 0xF0000) >> 16;
    System.out.printf("Executing instruction with opcode: %X%n", opcode); // Print opcode

    switch (opcode) {
        case 0:
            halt();
            return true;
        case 1:
            load(IR);
            break;
        case 2:
            loadc(IR);
            break;
        // Add cases for other instructions...
    }

    PC++; // Increment PC after executing the instruction
    return false;
}


    private void halt() {
        //Do nothing
    }

    private void load(int instruction) {
        int a = (instruction & 0xF00) >> 8;
        int b = instruction & 0xFF;
        registers[a] = memory.read(b);
    }

    private void loadc(int instruction) {
        int a = (instruction & 0xF00) >> 8;
        registers[a] = memory.read(PC++);
    }
}
