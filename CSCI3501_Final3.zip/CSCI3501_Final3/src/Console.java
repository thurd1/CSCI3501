import java.util.*;
import java.io.*;

public class Console {

    private Scanner kbd = new Scanner(System.in);
    private Memory memory;
    private Processor cpu;

    public Console(int cap) {
        memory = new Memory(cap);
        cpu = new Processor(memory);
    }

    public Console() {
        this(256);
    }

    public void load(String fName) {
        try {
            File f = new File(fName);
            Scanner scan = new Scanner(f);
            int address = 0;
            if (fName.endsWith(".asm.txt")) {
                while (scan.hasNext()) { //Handle AL instructions
                    String line = scan.nextLine();
                    String[] parts = line.split(" ");
                    String opcode = parts[0];
                    if (opcode.equalsIgnoreCase("loadc")) {
                        int operand = Integer.parseInt(parts[1], 16);
                        memory.write(address++, 0x200000 + operand);
                    } else {
                        int opcodeVal = 0;
                        switch (opcode.toLowerCase()) {
                            case "halt":
                                opcodeVal = 0x100000;
                                break;
                            case "load":
                                opcodeVal = 0x300000;
                                break;
                            case "store":
                                opcodeVal = 0x500000;
                                break;
                            case "add":
                                opcodeVal = 0x400000;
                                break;
                            default:
                                System.out.println("Invalid assembly instruction: " + line);
                                continue; //Continue to the next iteration
                        }
                        int operand1 = Integer.parseInt(parts[1], 16);
                        int operand2 = Integer.parseInt(parts[2], 16);
                        memory.write(address++, opcodeVal + (operand1 << 8) + operand2);
                    }
                }
            } else {
                while (scan.hasNext()) { //Handle hexadecimal ML
                    memory.write(address++, scan.nextInt(16));
                }
            }
            cpu.setPC(0);
            scan.close();
            System.out.println("Loaded program from file: " + fName);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void help() {
        System.out.println("load fileName \t loads hex memory image into memory");
        System.out.println("memory \t\t dumps memory to console");
        System.out.println("registers \t dumps registers to console");
        System.out.println("step N \t\t executes next N instructions or until halt");
        System.out.println("help \t\t displays this message");
        System.out.println("quit \t\t terminate console");
    }

    public void controlLoop() {
        System.out.println("type \"help\" for commands");
        while (true) {
            System.out.print("-> ");
            String cmmd = kbd.next();
            if (cmmd.equals("quit")) {
                break;
            } else if (cmmd.equals("help")) {
                help();
            } else if (cmmd.equals("load")) {
                load(kbd.next());
                System.out.println("done");
            } else if (cmmd.equals("memory")) {
                memory.dump();
            } else if (cmmd.equals("registers")) {
                cpu.dump();
            } else if (cmmd.equals("step")) {
                int num;
                if (!kbd.hasNextInt()) {
                    num = 0;
                    kbd.nextLine();
                    System.out.println("invalid number of steps");
                } else {
                    num = kbd.nextInt();
                    System.out.println("number of steps: " + num);
                    boolean halt = false;
                    for (int i = 0; i < num && !halt; i++) {
                        halt = cpu.step();
                        if (halt) {
                            System.out.println("program terminated");
                        }
                    }
                    System.out.println("done");
                }
            } else {
                System.out.println("unrecognized command: " + cmmd);
                if (kbd.hasNext()) {
                    kbd.nextLine();
                }
            }
        }
        System.out.println("bye");
    }

    public static void main(String[] args) {
        Console console = new Console();
        console.controlLoop();
    }
}
