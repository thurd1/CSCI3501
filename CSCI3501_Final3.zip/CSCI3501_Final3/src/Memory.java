public class Memory {

    private int[] cells;

    public Memory(int capacity) {
        cells = new int[capacity];
    }

    public int read(int address) {
        if (isValidAddress(address)) {
            return cells[address];
        } else {
            throw new IllegalArgumentException("Invalid memory address: " + address);
        }
    }

    public void write(int address, int data) {
        if (isValidAddress(address)) {
            cells[address] = data;
        } else {
            throw new IllegalArgumentException("Invalid memory address: " + address);
        }
    }

    public void dump() {
        for (int i = 0; i < cells.length; i++) {
            System.out.printf("cell[%X] = %X%n", i, cells[i]); //Formatted as hexadecimal
        }
    }

    private boolean isValidAddress(int address) {
        return address >= 0 && address < cells.length;
    }
}
